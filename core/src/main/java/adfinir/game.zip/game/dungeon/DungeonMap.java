package adfinir.game.dungeon;

import com.badlogic.gdx.math.MathUtils;
import com.badlogic.gdx.math.Vector2;
import java.util.ArrayList;
import java.util.List;

/**
 * Représente la carte du donjon sous forme de grille d'entiers.
 *
 * Valeurs de tiles :
 *   0 = VIDE (hors carte)
 *   1 = MUR
 *   2 = SOL
 *   3 = SORTIE (vers l'étage suivant)
 *   4 = LOOT (tile générant un objet au sol)
 */
public class DungeonMap {

    public static final int TILE_EMPTY = 0;
    public static final int TILE_WALL  = 1;
    public static final int TILE_FLOOR = 2;
    public static final int TILE_EXIT  = 3; // portail vers le niveau suivant
    public static final int TILE_LOOT  = 4; // tile générant un objet de loot

    public static final int TILE_SIZE = 16; // pixels par tile

    private final int[][] grid;
    public final int cols;
    public final int rows;
    public final int spawnCol;
    public final int spawnRow;
    public final int exitCol;
    public final int exitRow;

    /** Constructeur utilisé par DungeonGenerator (avec spawn et exit). */
    public DungeonMap(int[][] grid, int spawnCol, int spawnRow, int exitCol, int exitRow) {
        this.grid     = grid;
        this.rows     = grid.length;
        this.cols     = (rows > 0) ? grid[0].length : 0;
        this.spawnCol = spawnCol;
        this.spawnRow = spawnRow;
        this.exitCol  = exitCol;
        this.exitRow  = exitRow;
    }

    /** Constructeur legacy pour les cartes statiques. */
    public DungeonMap(int[][] grid, int spawnCol, int spawnRow) {
        this(grid, spawnCol, spawnRow, grid[0].length / 2, grid.length / 2);
    }

    /** Constructeur pour les cartes statiques. */
    public DungeonMap(int[][] grid) {
        this(grid, grid[0].length / 2, grid.length / 2);
    }

    /** Retourne le type de tile à la position grille (col, row). */
    public int getTile(int col, int row) {
        if (col < 0 || row < 0 || col >= cols || row >= rows) return TILE_WALL;
        return grid[row][col];
    }

    /** Retourne vrai si la position pixel (px, py) tombe sur une tile solide. */
    public boolean isSolid(float px, float py) {
        int col  = (int) Math.floor(px / TILE_SIZE);
        int row  = (int) Math.floor(py / TILE_SIZE);
        int tile = getTile(col, row);
        return tile == TILE_WALL || tile == TILE_EMPTY;
    }

    /** Coordonnée X pixel du centre de spawn. */
    public float getSpawnPixelX() { return spawnCol * TILE_SIZE + TILE_SIZE / 2f; }

    /** Coordonnée Y pixel du centre de spawn. */
    public float getSpawnPixelY() { return spawnRow * TILE_SIZE + TILE_SIZE / 2f; }

    /** Retourne la largeur totale de la carte en pixels. */
    public float getPixelWidth()  { return cols * TILE_SIZE; }

    /** Retourne la hauteur totale de la carte en pixels. */
    public float getPixelHeight() { return rows * TILE_SIZE; }

    /** Retourne une position pixel aléatoire sur une tile de sol. */
    public Vector2 getRandomFloorPosition() {
        List<int[]> floors = new ArrayList<>();
        for (int r = 0; r < rows; r++) {
            for (int c = 0; c < cols; c++) {
                if (getTile(c, r) == TILE_FLOOR) {
                    floors.add(new int[]{c, r});
                }
            }
        }
        if (floors.isEmpty()) return new Vector2(getSpawnPixelX(), getSpawnPixelY());

        int[] picked = floors.get(MathUtils.random(floors.size()));
        float px = picked[0] * TILE_SIZE + TILE_SIZE / 2f;
        float py = picked[1] * TILE_SIZE + TILE_SIZE / 2f;
        return new Vector2(px, py);
    }

    /**
     * Crée une carte de test statique (20×15 tiles).
     */
    public static DungeonMap createTestMap() {
        int W = TILE_WALL;
        int F = TILE_FLOOR;
        int[][] layout = {
            {W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W},
            {W,F,F,F,F,F,F,F,W,F,F,F,F,F,F,F,F,F,F,W},
            {W,F,F,F,F,F,F,F,W,F,F,F,F,F,F,F,F,F,F,W},
            {W,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,W},
            {W,F,F,F,W,W,F,F,W,F,F,W,W,F,F,F,F,F,F,W},
            {W,F,F,F,W,W,F,F,W,F,F,W,W,F,F,F,F,F,F,W},
            {W,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,W},
            {W,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,W},
            {W,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,W},
            {W,F,F,W,W,F,F,F,F,F,F,F,F,F,W,W,F,F,F,W},
            {W,F,F,W,W,F,F,F,F,F,F,F,F,F,W,W,F,F,F,W},
            {W,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,W},
            {W,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,W},
            {W,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,W},
            {W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W},
        };
        return new DungeonMap(layout);
    }
}
